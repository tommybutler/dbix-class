# keep stricture tests happy
use strict;
use warnings;
1;
